package calculator.kivubox.www.calculator;

import android.os.Vibrator;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.fathzer.soft.javaluator.DoubleEvaluator;

public class MainActivity extends AppCompatActivity {

    Vibrator v ;

    Button par1,par2,btn1,btn2,btn3,btn4,btn5,btn6,btn7,btn8,btn9,btn0,dot,plus,min,div,mult,equal,sin,cos,tan,ln,mod
            ,sqrt,log,power,pi,e,x,y,z,b1,b2,btnShow;

    ImageButton clear,backspace;
    FloatingActionButton fab;

    TextView expression,expression2,answer;

    Double result ;

    String exp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        v = (Vibrator) getSystemService(this.VIBRATOR_SERVICE);

        initWidgets();

    }

    public void initWidgets(){

        View.OnClickListener btn= new View.OnClickListener(){
            @Override
            public void onClick(View view) {

                btnShow = findViewById(view.getId());
                inExp(btnShow.getText().toString().toLowerCase());

                v.vibrate(50);

            }
        };

        backspace = findViewById(R.id.backspace);
        fab = findViewById(R.id.fab);
        clear = findViewById(R.id.clear);
        backspace.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                v.vibrate(50);

                String v = expression.getText().toString();
                if(v !=null && v.length()>0) {
                    v = v.substring(0, v.length() - 1);
                    expression.setText(v);
                    expression2.setText(v);
                }
            }
        });
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                v.vibrate(50);

                String v = expression.getText().toString();
                if(v !=null && v.length()>0) {
                    v = v.substring(0, v.length() - 1);
                    expression.setText(v);
                    expression2.setText(v);
                }
            }
        });
        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                v.vibrate(50);

                expression.setText("");
                expression2.setText("");
            }
        });

        answer = findViewById(R.id.answer);

        Button equal = findViewById(R.id.equal);
        equal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                try{

                    v.vibrate(50);

                    exp = expression.getText().toString();

                    result = new DoubleEvaluator().evaluate(exp);
                    
                }catch (Exception e){
                    v.vibrate(400);
                    Toast.makeText(MainActivity.this, "SYNTAX ERROR", Toast.LENGTH_SHORT).show();
                }

                answer.setText(result.toString());

            }
        });

        expression = findViewById(R.id.expression);
        expression2 = findViewById(R.id.expression2);

        Button par1 = findViewById(R.id.para1);
        par1.setOnClickListener(btn);
        Button par2 = findViewById(R.id.para2);
        par2.setOnClickListener(btn);
        Button btn1 = findViewById(R.id.btn1);
        btn1.setOnClickListener(btn);
        Button btn2 = findViewById(R.id.btn2);
        btn2.setOnClickListener(btn);
        Button btn3 = findViewById(R.id.btn3);
        btn3.setOnClickListener(btn);
        Button btn4 = findViewById(R.id.btn4);
        btn4.setOnClickListener(btn);
        Button btn5 = findViewById(R.id.btn5);
        btn5.setOnClickListener(btn);
        Button btn6 = findViewById(R.id.btn6);
        btn6.setOnClickListener(btn);
        Button btn7 = findViewById(R.id.btn7);
        btn7.setOnClickListener(btn);
        Button btn8 = findViewById(R.id.btn8);
        btn8.setOnClickListener(btn);
        Button btn9 = findViewById(R.id.btn9);
        btn9.setOnClickListener(btn);
        Button btn0 = findViewById(R.id.btn0);
        btn0.setOnClickListener(btn);
        Button dot = findViewById(R.id.dot);
        dot.setOnClickListener(btn);
        Button plus = findViewById(R.id.plus);
        plus.setOnClickListener(btn);
        Button min = findViewById(R.id.min);
        min.setOnClickListener(btn);
        Button div = findViewById(R.id.div);
        div.setOnClickListener(btn);
        Button mult = findViewById(R.id.mult);
        mult.setOnClickListener(btn);
        Button sin = findViewById(R.id.sin);
        sin.setOnClickListener(btn);
        Button cos = findViewById(R.id.cos);
        cos.setOnClickListener(btn);
        Button tan = findViewById(R.id.tan);
        tan.setOnClickListener(btn);
        Button ln = findViewById(R.id.ln);
        ln.setOnClickListener(btn);
        Button mod = findViewById(R.id.mod);
        mod.setOnClickListener(btn);
        Button sqrt = findViewById(R.id.sqrt);
        sqrt.setOnClickListener(btn);
        Button log = findViewById(R.id.log);
        log.setOnClickListener(btn);
        Button power = findViewById(R.id.power);
        power.setOnClickListener(btn);
        Button pi = findViewById(R.id.pi);
        pi.setOnClickListener(btn);
        Button e = findViewById(R.id.e);
        e.setOnClickListener(btn);
        Button x = findViewById(R.id.x);
        x.setOnClickListener(btn);
        Button y = findViewById(R.id.y);
        y.setOnClickListener(btn);
        Button z = findViewById(R.id.z);
        z.setOnClickListener(btn);
        Button b1 = findViewById(R.id.b1);
        b1.setOnClickListener(btn);
        Button b2 = findViewById(R.id.b2);
        b2.setOnClickListener(btn);


    }

    public void inExp(String v){
        expression.append(v);
        expression2.append(v);
    }

}
